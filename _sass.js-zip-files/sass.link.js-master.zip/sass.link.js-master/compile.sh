#!/bin/sh

webmerge -f "`dirname $0`"/conf/sass.js.conf.xml "$@"